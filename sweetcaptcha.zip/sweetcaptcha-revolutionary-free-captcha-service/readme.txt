=== SweetCaptcha ===
Contributors: SweetCaptcha.com ltd.
Author URI: http://www.sweetcaptcha.com
Tags: captcha, anti-spam, captcha contact form 7, register, comment, login, sign-up
Requires at least: 2.8
Tested up to: 3.1
Stable tag: trunk

== Description ==

SweetCaptcha is anti-spam solution for Wordpress forms, Contact Form 7, and BuddyPress.

== Installation ==

Download SweetCaptcha archive, and extract to wp-content/plugins, 
or follow plug-in installation guide at Wordpress Codex.

== Requirements ==

Wordpress >= 2.8, cURL extension

== Changelog ==

= 1.0 =
* Initial version
